import { useState } from 'react';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<{score: number, explanation: string} | null>(null);
  const handleEvaluate = () => {
    if (!input.trim()) return;
    const words = input.trim().split(/\s+/).length;
    const weight = Number((import.meta as any).env.VITE_SCORING_WEIGHT) || 1;
    const score = Math.min(100, Math.max(0, words * weight)); 
    setResult({
      score,
      explanation: `Explainable AI(Not Really Implemented Yet): The candidate wrote ${words} words. We give ${weight} point(s) per word up to 100.`
    });
  };
  return (
    <div className="min-h-screen bg-gray-100 p-8 font-sans text-gray-900 flex items-center justify-center">
      <div className="max-w-lg w-full bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h1 className="text-2xl font-bold mb-2">IVisionU</h1>
        <p className="mb-6 text-sm text-gray-500">
          Minimal Candidate Selection Support System.
        </p>
        <textarea 
          className="w-full border border-gray-300 p-3 rounded mb-4 h-40 focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Paste candidate application or essay here..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button 
          className="w-full bg-blue-600 text-white font-medium px-4 py-2 rounded hover:bg-blue-700 transition-colors"
          onClick={handleEvaluate}
        >
          Analyze Candidate
        </button>
        {result && (
          <div className="mt-6 p-4 bg-blue-50 rounded border border-blue-100">
            <h2 className="text-sm font-semibold text-blue-800 uppercase tracking-wider mb-1">Evaluation Result</h2>
            <p className="text-4xl font-bold text-blue-900 mb-3">{result.score} <span className="text-lg text-blue-700 font-normal">/ 100</span></p>
            <div className="text-sm text-blue-800">
              <strong>Reasoning:</strong> {result.explanation}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
